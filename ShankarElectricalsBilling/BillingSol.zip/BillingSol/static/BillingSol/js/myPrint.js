﻿function Print() {
    $(".hidewhenPrint").hide();
    window.print();
    $(".hidewhenPrint").show();
}